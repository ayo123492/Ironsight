| How to install | 
1. Choose a weapon animation that you want, there are reanimated weapon and default weapon but fixed (Optional) 
2. Copy all the CFG file and the folder except for "must read" and if you want a weapon reanimated or default fixed weapon then go into the folder you want and copy all the file into your models folder

Note:
The reanimated weapon only change the animation of the weapon it doesn't change the animation when in aim mode